package com.example.imagecrypt

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import android.provider.OpenableColumns
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class MainActivity : Activity() {
    private lateinit var plain: EditText
    private lateinit var encPass: EditText
    private lateinit var encPass2: EditText
    private lateinit var decPass: EditText
    private lateinit var result: EditText
    private lateinit var status: TextView
    private var encUri: Uri? = null
    private var decUri: Uri? = null
    private val PICK_ENC = 101
    private val PICK_DEC = 102
    private val SAVE_PNG = 103
    private var pendingPng: ByteArray? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(36,92,226)
        window.navigationBarColor = Color.rgb(16,24,39)
        buildUi()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun addLabel(parent: LinearLayout, text: String) {
        val tv = TextView(this); tv.text = text; tv.textSize = 15f
        tv.setTextColor(Color.rgb(42,53,73)); tv.setPadding(0, dp(12), 0, dp(6))
        parent.addView(tv)
    }
    private fun edit(hint: String, password: Boolean = false, multiline: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint; e.textSize = 16f; e.setPadding(dp(12),dp(10),dp(12),dp(10))
        if (password) e.inputType = 129
        if (multiline) { e.minLines = 3; e.gravity = android.view.Gravity.TOP; e.inputType = 1 or 0x00020000 }
        return e
    }
    private fun button(text: String, action: () -> Unit): Button {
        val b = Button(this); b.text = text; b.setOnClickListener { action() }; return b
    }
    private fun buildUi() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this); page.orientation = LinearLayout.VERTICAL
        page.setPadding(dp(18), dp(16), dp(18), dp(24))
        page.setBackgroundColor(Color.rgb(243,246,251))
        scroll.addView(page)
        val title = TextView(this); title.text = "图片文字加解密"; title.textSize = 26f
        title.setTextColor(Color.rgb(27,38,59)); title.setTypeface(null, 1)
        page.addView(title)
        val intro = TextView(this)
        intro.text = "原生安卓应用：直接调用系统文件/图片选择器，不需要在浏览器里操作。图片和文字只在本机处理。"
        intro.textSize = 14f; intro.setTextColor(Color.rgb(94,105,124))
        intro.setPadding(0, dp(8), 0, dp(12)); page.addView(intro)

        val warning = TextView(this)
        warning.text = "注意：普通照片不能凭空解密出文字。必须先由本工具生成加密图片，并保留原始 PNG；经过压缩、裁剪或转换可能导致解密失败。"
        warning.textSize = 13f; warning.setTextColor(Color.rgb(91,70,28))
        warning.setPadding(dp(12),dp(12),dp(12),dp(12)); warning.setBackgroundColor(Color.rgb(255,246,222))
        page.addView(warning)

        val encTitle = TextView(this); encTitle.text = "一、加密文字到图片"; encTitle.textSize = 20f
        encTitle.setTypeface(null,1); encTitle.setTextColor(Color.rgb(35,48,70))
        encTitle.setPadding(0,dp(20),0,dp(2)); page.addView(encTitle)
        addLabel(page,"需要加密的文字")
        plain = edit("输入秘密文字", multiline = true); page.addView(plain, matchWrap())
        addLabel(page,"设置密码")
        encPass = edit("设置加密密码", password=true); page.addView(encPass, matchWrap())
        addLabel(page,"再次输入密码")
        encPass2 = edit("再次输入密码", password=true); page.addView(encPass2, matchWrap())
        page.addView(button("📷 从相册 / 文件选择原图") { pick(PICK_ENC) }, matchWrap())
        page.addView(button("加密并保存 PNG 图片") { encryptImage() }, matchWrap())

        val decTitle = TextView(this); decTitle.text = "二、解密图片"; decTitle.textSize = 20f
        decTitle.setTypeface(null,1); decTitle.setTextColor(Color.rgb(35,48,70))
        decTitle.setPadding(0,dp(22),0,dp(2)); page.addView(decTitle)
        page.addView(button("🖼️ 选择需要解密的图片") { pick(PICK_DEC) }, matchWrap())
        addLabel(page,"解密密码")
        decPass = edit("输入加密时设置的密码", password=true); page.addView(decPass, matchWrap())
        page.addView(button("提取并解密文字") { decryptImage() }, matchWrap())
        addLabel(page,"解密结果")
        result = edit("解密成功后会显示在这里", multiline=true); result.isFocusable = true
        page.addView(result, matchWrap())
        page.addView(button("复制解密结果") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("解密结果", result.text.toString()))
            toast("已复制")
        }, matchWrap())
        addLabel(page,"运行状态")
        status = TextView(this); status.text = "请选择加密或解密操作。"; status.textSize=14f
        status.setTextColor(Color.rgb(68,80,101)); status.setPadding(0,dp(6),0,dp(12)); page.addView(status)
        setContentView(scroll)
    }
    private fun matchWrap(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).also { it.bottomMargin = dp(5) }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun pick(code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
        }
        startActivityForResult(i, code)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            PICK_ENC -> { encUri = uri; status.text = "已选择原图：" + displayName(uri) }
            PICK_DEC -> { decUri = uri; status.text = "已选择待解密图片：" + displayName(uri) }
            SAVE_PNG -> {
                val bytes = pendingPng ?: return
                try { contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    status.text = "已保存加密图片。请保留 PNG 原文件和密码。"
                } catch (e: Exception) { status.text = "保存失败：" + e.message }
            }
        }
    }
    private fun displayName(uri: Uri): String {
        var name = "图片"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        return name
    }
    private fun readBitmap(uri: Uri): Bitmap {
        return contentResolver.openInputStream(uri).use { input ->
            BitmapFactory.decodeStream(input) ?: throw Exception("无法读取图片格式")
        }
    }
    private fun deriveKey(password: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password.toCharArray(), salt, 600000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return SecretKeySpec(bytes, "AES")
    }
    private fun encrypt(text: String, password: String): ByteArray {
        val salt = ByteArray(16); val nonce = ByteArray(12); SecureRandom().nextBytes(salt); SecureRandom().nextBytes(nonce)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, deriveKey(password,salt), GCMParameterSpec(128,nonce))
        val encrypted = cipher.doFinal(text.toByteArray(Charsets.UTF_8))
        return salt + nonce + encrypted
    }
    private fun decrypt(data: ByteArray, password: String): String {
        if (data.size < 44) throw Exception("隐藏数据不完整")
        val salt=data.copyOfRange(0,16); val nonce=data.copyOfRange(16,28); val ciphertext=data.copyOfRange(28,data.size)
        val cipher=Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE,deriveKey(password,salt),GCMParameterSpec(128,nonce))
        return cipher.doFinal(ciphertext).toString(Charsets.UTF_8)
    }
    private fun bitmapToRgb(bitmap: Bitmap): ByteArray {
        val w=bitmap.width; val h=bitmap.height
        val pixels=IntArray(w*h); bitmap.getPixels(pixels,0,w,0,0,w,h)
        val rgb=ByteArray(w*h*3); var j=0
        for (p in pixels) { rgb[j++]=Color.red(p).toByte(); rgb[j++]=Color.green(p).toByte(); rgb[j++]=Color.blue(p).toByte() }
        return rgb
    }
    private fun writeData(rgb: ByteArray, data: ByteArray) {
        val packet=ByteArray(4+data.size)
        packet[0]=(data.size ushr 24).toByte(); packet[1]=(data.size ushr 16).toByte()
        packet[2]=(data.size ushr 8).toByte(); packet[3]=data.size.toByte()
        System.arraycopy(data,0,packet,4,data.size)
        if (packet.size.toLong()*8L > rgb.size.toLong()) throw Exception("图片像素容量不足，请选择更高分辨率的图片")
        var pos=0
        for (b in packet) for (shift in 7 downTo 0) {
            val bit=(b.toInt() ushr shift) and 1
            rgb[pos]=((rgb[pos].toInt() and 0xFE) or bit).toByte(); pos++
        }
    }
    private fun extractData(rgb: ByteArray): ByteArray {
        if (rgb.size < 32) throw Exception("图片太小")
        fun readBytes(start: Int, count: Int): ByteArray {
            val out=ByteArray(count); var p=start
            for (i in 0 until count) {
                var v=0
                for (j in 0 until 8) v=(v shl 1) or (rgb[p++].toInt() and 1)
                out[i]=v.toByte()
            }
            return out
        }
        val header=readBytes(0,4)
        val len=((header[0].toLong() and 255) shl 24) or ((header[1].toLong() and 255) shl 16) or
                ((header[2].toLong() and 255) shl 8) or (header[3].toLong() and 255)
        val capacity=rgb.size.toLong()/8L-4L
        if (len < 44 || len > capacity || len > Int.MAX_VALUE) throw Exception("没有找到本工具格式的隐藏数据，或图片被压缩/修改")
        return readBytes(32,len.toInt())
    }
    private fun encryptImage() {
        try {
            val text=plain.text.toString(); val p1=encPass.text.toString(); val p2=encPass2.text.toString()
            val uri=encUri
            if(text.isBlank()) throw Exception("请先输入需要加密的文字")
            if(p1.isEmpty()) throw Exception("请设置密码")
            if(p1!=p2) throw Exception("两次密码不一致")
            if(uri==null) throw Exception("请先选择原始图片")
            status.text="正在加密…"
            val bitmap=readBitmap(uri).copy(Bitmap.Config.ARGB_8888,true)
            val rgb=bitmapToRgb(bitmap); val packed=encrypt(text,p1); writeData(rgb,packed)
            val pixels=IntArray(bitmap.width*bitmap.height); var k=0
            for(i in pixels.indices) {
                val r=rgb[k++].toInt() and 255; val g=rgb[k++].toInt() and 255; val b=rgb[k++].toInt() and 255
                pixels[i]=Color.rgb(r,g,b)
            }
            bitmap.setPixels(pixels,0,bitmap.width,0,0,bitmap.width,bitmap.height)
            val out=ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.PNG,100,out)
            pendingPng=out.toByteArray()
            val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type="image/png"; putExtra(Intent.EXTRA_TITLE,"加密图片.png")
            }
            startActivityForResult(intent,SAVE_PNG)
        } catch(e: Exception) { status.text="加密失败：" + (e.message ?: "请检查图片") }
    }
    private fun decryptImage() {
        try {
            val uri=decUri ?: throw Exception("请先选择需要解密的图片")
            val password=decPass.text.toString()
            if(password.isEmpty()) throw Exception("请输入解密密码")
            status.text="正在读取并解密…"
            val bitmap=readBitmap(uri)
            val data=extractData(bitmapToRgb(bitmap))
            result.setText(decrypt(data,password))
            status.text="解密成功，可以复制结果。"
        } catch(e: Exception) {
            result.setText("")
            status.text=if (e is javax.crypto.AEADBadTagException) "解密失败：密码错误或图片数据已损坏。" else "处理失败：" + (e.message ?: "请检查图片和密码")
        }
    }
}
